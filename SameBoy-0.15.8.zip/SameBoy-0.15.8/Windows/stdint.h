#pragma once
#include_next <stdint.h>
typedef intptr_t ssize_t;