#pragma once
#include_next <stdlib.h>
#define alloca _alloca
