#ifndef open_rom_h
#define open_rom_h

char *do_open_rom_dialog(void);
char *do_open_folder_dialog(void);
char *do_save_recording_dialog(unsigned frequency);
#endif /* open_rom_h */
