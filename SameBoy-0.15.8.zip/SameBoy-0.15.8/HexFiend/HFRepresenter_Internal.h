#import <HexFiend/HFRepresenter.h>

@interface HFRepresenter (HFInternalStuff)

- (void)_setController:(HFController *)controller;

@end
