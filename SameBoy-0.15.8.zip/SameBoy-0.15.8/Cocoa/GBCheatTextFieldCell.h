#import <Cocoa/Cocoa.h>

@interface GBCheatTextFieldCell : NSTextFieldCell
@property (nonatomic) bool usesAddressFormat;
@end
