#import <Cocoa/Cocoa.h>

/* Fake interface so the compiler assumes it conforms to NSVisualEffectView */
@interface GBOptionalVisualEffectView : NSVisualEffectView

@end
