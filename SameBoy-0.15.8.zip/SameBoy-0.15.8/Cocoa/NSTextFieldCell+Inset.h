#import <AppKit/AppKit.h>
#import <Cocoa/Cocoa.h>

@interface NSTextFieldCell (Inset)
@property NSSize textInset;
@end
