#import <Cocoa/Cocoa.h>

@interface GBTintedImageCell : NSImageCell
@property NSColor *tint;
@end
